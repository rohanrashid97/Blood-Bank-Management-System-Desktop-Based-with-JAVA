package BloodBankManagementSystem;

public class Remember {
    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}
