package BloodBankManagementSystem;

import javax.swing.JOptionPane;

public class UserHome extends javax.swing.JFrame {
    public UserHome() {
        initComponents();
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        addUser = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        bloodGrp = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        location = new javax.swing.JMenuItem();
        purchase = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        bloodPacketsDetails = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        jMenu5 = new javax.swing.JMenu();
        logoutItem = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        closeAppItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 770));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel2.setBackground(new java.awt.Color(255, 0, 0));
        jLabel2.setFont(new java.awt.Font("Candara", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Register for upcoming Blood Donation Camp ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 67, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/MainImage.jpg"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        addUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/newuser.png"))); // NOI18N
        addUser.setText("Users");
        addUser.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        addUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addUserActionPerformed(evt);
            }
        });

        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Add new.png"))); // NOI18N
        jMenuItem1.setText("Profile");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        addUser.add(jMenuItem1);

        jMenuBar1.add(addUser);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/search user.png"))); // NOI18N
        jMenu3.setText("Search Blood Donor");
        jMenu3.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N

        bloodGrp.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        bloodGrp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Blood group.png"))); // NOI18N
        bloodGrp.setText("Blood Group ");
        bloodGrp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bloodGrpActionPerformed(evt);
            }
        });
        jMenu3.add(bloodGrp);
        jMenu3.add(jSeparator3);

        location.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        location.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Location.png"))); // NOI18N
        location.setText("Location");
        location.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                locationActionPerformed(evt);
            }
        });
        jMenu3.add(location);

        jMenuBar1.add(jMenu3);

        purchase.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/stock.png"))); // NOI18N
        purchase.setText("Blood Stocks");
        purchase.setFocusable(false);
        purchase.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        purchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purchaseActionPerformed(evt);
            }
        });

        jMenuItem6.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        jMenuItem6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Address.png"))); // NOI18N
        jMenuItem6.setText("Purchase of Blood");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        purchase.add(jMenuItem6);
        purchase.add(jSeparator4);

        bloodPacketsDetails.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        bloodPacketsDetails.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/save.png"))); // NOI18N
        bloodPacketsDetails.setText("Stock Details");
        bloodPacketsDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bloodPacketsDetailsActionPerformed(evt);
            }
        });
        purchase.add(bloodPacketsDetails);
        purchase.add(jSeparator5);

        jMenuBar1.add(purchase);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/exit.png"))); // NOI18N
        jMenu5.setText("Exit");
        jMenu5.setFocusable(false);
        jMenu5.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N

        logoutItem.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        logoutItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logout.png"))); // NOI18N
        logoutItem.setText("Logout");
        logoutItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutItemActionPerformed(evt);
            }
        });
        jMenu5.add(logoutItem);
        jMenu5.add(jSeparator6);

        closeAppItem.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        closeAppItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Exit application.png"))); // NOI18N
        closeAppItem.setText("Close Application");
        closeAppItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeAppItemActionPerformed(evt);
            }
        });
        jMenu5.add(closeAppItem);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bloodGrpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bloodGrpActionPerformed
        new SearchDonorByBloodGrp().setVisible(true);
    }//GEN-LAST:event_bloodGrpActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        new SellBlood().setVisible(true);
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void bloodPacketsDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bloodPacketsDetailsActionPerformed
        new NoOfBloodPackets().setVisible(true);
    }//GEN-LAST:event_bloodPacketsDetailsActionPerformed

    private void logoutItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutItemActionPerformed
        int a = JOptionPane.showConfirmDialog(null, "Do you want to logout ? ", "Select", JOptionPane.YES_NO_OPTION);
        if (a == 0) {
            setVisible(false);
            new Login().setVisible(true);
        }
    }//GEN-LAST:event_logoutItemActionPerformed

    private void closeAppItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeAppItemActionPerformed
        int a = JOptionPane.showConfirmDialog(null, "Do you want to close application ? ", "Select", JOptionPane.YES_NO_OPTION);
        if (a == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_closeAppItemActionPerformed

    private void locationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_locationActionPerformed
        new SearchDonorByLocation().setVisible(true);
    }//GEN-LAST:event_locationActionPerformed

    private void purchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purchaseActionPerformed

    }//GEN-LAST:event_purchaseActionPerformed

    private void addUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addUserActionPerformed

    }//GEN-LAST:event_addUserActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        new UserProfileDetails().setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserHome().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu addUser;
    private javax.swing.JMenuItem bloodGrp;
    private javax.swing.JMenuItem bloodPacketsDetails;
    private javax.swing.JMenuItem closeAppItem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JMenuItem location;
    private javax.swing.JMenuItem logoutItem;
    private javax.swing.JMenu purchase;
    // End of variables declaration//GEN-END:variables
}
