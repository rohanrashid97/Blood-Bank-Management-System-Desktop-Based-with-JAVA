package BloodBankManagementSystem;


class ResultSet {

    boolean first() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}
