package BloodBankManagementSystem;

import ProjBack.ConnectionProvider;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


public class AddNewUser extends javax.swing.JFrame {
    public static String bg;
    public AddNewUser() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        donorId = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        uMobile = new javax.swing.JTextField();
        uRole = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        uEmail = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        uAddress = new javax.swing.JTextArea();
        uCity = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        saveBtn = new javax.swing.JButton();
        resetBtn = new javax.swing.JButton();
        closebtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        uFullname = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        userName = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        uPassword = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        gender1 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(250, 90));
        setUndecorated(true);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Candara", 1, 30)); // NOI18N
        jLabel1.setText("Add New User");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(333, 11, -1, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 59, 801, 10));

        jLabel2.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel2.setText("New User Id");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(54, 89, -1, -1));

        donorId.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        donorId.setForeground(new java.awt.Color(255, 0, 0));
        getContentPane().add(donorId, new org.netbeans.lib.awtextra.AbsoluteConstraints(183, 87, 170, -1));

        jLabel8.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel8.setText("Mobile No.");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, -1, -1));

        jLabel9.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel9.setText("Gender");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, -1, -1));

        uMobile.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        uMobile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uMobileActionPerformed(evt);
            }
        });
        getContentPane().add(uMobile, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 160, -1));

        uRole.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        uRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "admin", "user" }));
        uRole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uRoleActionPerformed(evt);
            }
        });
        getContentPane().add(uRole, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 170, -1));

        jLabel10.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel10.setText("Email ");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 128, 40, -1));

        jLabel12.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel12.setText("Address");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 180, -1, -1));

        jLabel13.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel13.setText("City");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 300, 40, 20));

        uEmail.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        uEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uEmailActionPerformed(evt);
            }
        });
        getContentPane().add(uEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(585, 125, 170, -1));

        uAddress.setColumns(20);
        uAddress.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        uAddress.setRows(5);
        jScrollPane1.setViewportView(uAddress);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 170, 170, -1));

        uCity.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        getContentPane().add(uCity, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 300, 170, -1));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, 801, 10));

        saveBtn.setBackground(new java.awt.Color(0, 153, 0));
        saveBtn.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        saveBtn.setForeground(new java.awt.Color(255, 255, 255));
        saveBtn.setText("Save");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });
        getContentPane().add(saveBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 370, 90, 40));

        resetBtn.setBackground(new java.awt.Color(0, 153, 255));
        resetBtn.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        resetBtn.setForeground(new java.awt.Color(255, 255, 255));
        resetBtn.setText("Reset");
        resetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBtnActionPerformed(evt);
            }
        });
        getContentPane().add(resetBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 370, 90, 40));

        closebtn.setBackground(new java.awt.Color(255, 0, 51));
        closebtn.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        closebtn.setForeground(new java.awt.Color(255, 255, 255));
        closebtn.setText("Close");
        closebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closebtnActionPerformed(evt);
            }
        });
        getContentPane().add(closebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 370, 90, 40));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, -1));
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, -1, -1));

        jLabel5.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel5.setText("User Role");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, -1));

        uFullname.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        uFullname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uFullnameActionPerformed(evt);
            }
        });
        getContentPane().add(uFullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 170, -1));

        jLabel7.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel7.setText("Username");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, -1, -1));

        userName.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        userName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userNameActionPerformed(evt);
            }
        });
        getContentPane().add(userName, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 120, 170, -1));

        jLabel11.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel11.setText("Password");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, -1, -1));

        uPassword.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        uPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uPasswordActionPerformed(evt);
            }
        });
        getContentPane().add(uPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, 170, -1));

        jLabel6.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel6.setText("Full Name");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, -1, -1));

        gender1.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        gender1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", "Others" }));
        gender1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gender1ActionPerformed(evt);
            }
        });
        getContentPane().add(gender1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 170, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        try{
            Connection conn = ConnectionProvider.getCon();
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery("select max(id) from users");
            if (rs.first()) {
                int id = rs.getInt(1);
                id = id + 1;
                String str = String.valueOf(id);
                donorId.setText(str);
            }
            else {
                donorId.setText("1");
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formComponentShown

    private void uRoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uRoleActionPerformed

    }//GEN-LAST:event_uRoleActionPerformed

    private void uEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uEmailActionPerformed

    }//GEN-LAST:event_uEmailActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        String userID = donorId.getText();
        String username = userName.getText();
        String password = uPassword.getText();
        String userRole = (String)uRole.getSelectedItem();
        String fullname = uFullname.getText();
        String mobile = uMobile.getText();
        String email = uEmail.getText();
        String address = uAddress.getText();
        String city = uCity.getText();
        
        try{
            Connection conn = ConnectionProvider.getCon();
            Statement stat = conn.createStatement();
            stat.executeUpdate("insert into users (username, password, user_role, fullname, email, mobile, address, city ) values ('" +username+ "', '" +password+ "', '" +userRole+"', '" +fullname+ "', '" +email+ "', '" +mobile+ "', '" +address+ "', '" +city+ "')");
            JOptionPane.showMessageDialog(null, "New User Added Successful! Thank You");
            setVisible(false);
            new AddNewUser().setVisible(true);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Something went wrong!");
        }
    }//GEN-LAST:event_saveBtnActionPerformed

    private void closebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closebtnActionPerformed
        setVisible(false);
    }//GEN-LAST:event_closebtnActionPerformed

    private void resetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBtnActionPerformed
        setVisible(false);
        new AddNewUser().setVisible(true);
    }//GEN-LAST:event_resetBtnActionPerformed

    private void uFullnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uFullnameActionPerformed

    }//GEN-LAST:event_uFullnameActionPerformed

    private void userNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userNameActionPerformed

    }//GEN-LAST:event_userNameActionPerformed

    private void uMobileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uMobileActionPerformed

    }//GEN-LAST:event_uMobileActionPerformed

    private void uPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uPasswordActionPerformed

    }//GEN-LAST:event_uPasswordActionPerformed

    private void gender1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gender1ActionPerformed

    }//GEN-LAST:event_gender1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddNewUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton closebtn;
    private javax.swing.JLabel donorId;
    private javax.swing.JComboBox<String> gender1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JButton resetBtn;
    private javax.swing.JButton saveBtn;
    private javax.swing.JTextArea uAddress;
    private javax.swing.JTextField uCity;
    private javax.swing.JTextField uEmail;
    private javax.swing.JTextField uFullname;
    private javax.swing.JTextField uMobile;
    private javax.swing.JTextField uPassword;
    private javax.swing.JComboBox<String> uRole;
    private javax.swing.JTextField userName;
    // End of variables declaration//GEN-END:variables
}
