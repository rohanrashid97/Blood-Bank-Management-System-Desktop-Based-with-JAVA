package BloodBankManagementSystem;


import ProjBack.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

public class SellBlood extends javax.swing.JFrame {
    public static String bg;
   
    public SellBlood() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        pName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        pDob = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        pMobile = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        pGender = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        pEmail = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        pAddress = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        pCity = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        submitBtn = new javax.swing.JButton();
        closeBtn = new javax.swing.JButton();
        resetBtn = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        pBloodGrp = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(270, 90));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Candara", 1, 30)); // NOI18N
        jLabel1.setText("Blood Donated To");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(292, 18, -1, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 66, 801, 10));

        jLabel2.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel2.setText("Full Name");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 119, -1, -1));

        pName.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        getContentPane().add(pName, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 116, 170, -1));

        jLabel3.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel3.setText("Date of Purchase");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 160, -1, -1));

        pDob.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        getContentPane().add(pDob, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 158, 170, -1));

        jLabel4.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel4.setText("Mobile No.");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 199, -1, -1));

        pMobile.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        getContentPane().add(pMobile, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 196, 170, -1));

        jLabel5.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel5.setText("Gender");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 241, -1, -1));

        pGender.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        pGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", "Others" }));
        pGender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pGenderActionPerformed(evt);
            }
        });
        getContentPane().add(pGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 238, 170, -1));

        jLabel6.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel6.setText("Email");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 283, -1, -1));

        pEmail.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        getContentPane().add(pEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 280, 170, -1));

        jLabel7.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel7.setText("Blood Group");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(472, 119, -1, -1));

        jLabel8.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel8.setText("Address");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(472, 158, -1, -1));

        pAddress.setColumns(20);
        pAddress.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        pAddress.setRows(5);
        jScrollPane1.setViewportView(pAddress);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(572, 158, 170, -1));

        jLabel9.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel9.setText("City");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(472, 283, -1, -1));

        pCity.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        getContentPane().add(pCity, new org.netbeans.lib.awtextra.AbsoluteConstraints(572, 280, 170, -1));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 365, 801, 10));

        submitBtn.setBackground(new java.awt.Color(0, 204, 0));
        submitBtn.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        submitBtn.setForeground(new java.awt.Color(255, 255, 255));
        submitBtn.setText("Submit");
        submitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtnActionPerformed(evt);
            }
        });
        getContentPane().add(submitBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 410, 103, 45));

        closeBtn.setBackground(new java.awt.Color(255, 51, 51));
        closeBtn.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        closeBtn.setForeground(new java.awt.Color(255, 255, 255));
        closeBtn.setText("Cancel");
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });
        getContentPane().add(closeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 410, 103, 45));

        resetBtn.setBackground(new java.awt.Color(51, 153, 255));
        resetBtn.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        resetBtn.setForeground(new java.awt.Color(255, 255, 255));
        resetBtn.setText("Reset");
        resetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBtnActionPerformed(evt);
            }
        });
        getContentPane().add(resetBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 410, 103, 45));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        pBloodGrp.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        pBloodGrp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" }));
        getContentPane().add(pBloodGrp, new org.netbeans.lib.awtextra.AbsoluteConstraints(572, 119, 170, -1));
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/allformsbg.png"))); // NOI18N
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pGenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pGenderActionPerformed

    }//GEN-LAST:event_pGenderActionPerformed

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        setVisible(false);
    }//GEN-LAST:event_closeBtnActionPerformed

    private void resetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBtnActionPerformed
        setVisible(false);
        new SellBlood().setVisible(true);
    }//GEN-LAST:event_resetBtnActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        String name = pName.getText();
        SimpleDateFormat dFormat = new SimpleDateFormat("dd-MM-yyyy");
        String dob = dFormat.format(pDob.getDate());
        String mobileNo = pMobile.getText();
        String gender = (String)pGender.getSelectedItem();
        String email = pEmail.getText();
        String bloodGrp = (String)pBloodGrp.getSelectedItem();
        String address = pAddress.getText();
        String city = pCity.getText();
        
        
        try{
            Connection conn = ConnectionProvider.getCon();            
            PreparedStatement stat = conn.prepareStatement("insert into patientdetails (name, dateOfPurchase, mobileNo, gender, email, bloodGrp, address, city ) values(?, ?, ?, ?, ?, ?, ?, ?)");
            stat.setString(1, name);
            stat.setString(2, dob);
            stat.setString(3, mobileNo);
            stat.setString(4, gender);
            stat.setString(5, email);
            stat.setString(6, bloodGrp);
            stat.setString(7, address);
            stat.setString(8, city);
            
            stat.executeUpdate();
            
            bg = pBloodGrp.getSelectedItem().toString();
            if (bg.equals("A+")) {
                stat = conn.prepareStatement("select packetsofBlood from bloodquantity where bloodGrp='"+bg+"'");
            }
            if (bg.equals("A-")) {
                stat = conn.prepareStatement("select packetsofBlood from bloodquantity where bloodGrp='"+bg+"'");
            }
            if (bg.equals("B+")) {
                stat = conn.prepareStatement("select packetsofBlood from bloodquantity where bloodGrp='"+bg+"'");
            }
            if (bg.equals("B-")) {
                stat = conn.prepareStatement("select packetsofBlood from bloodquantity where bloodGrp='"+bg+"'");
            }
            if (bg.equals("O+")) {
                stat = conn.prepareStatement("select packetsofBlood from bloodquantity where bloodGrp='"+bg+"'");
            }
            if (bg.equals("O-")) {
                stat = conn.prepareStatement("select packetsofBlood from bloodquantity where bloodGrp='"+bg+"'");
            }
            if (bg.equals("AB+")) {
                stat = conn.prepareStatement("select packetsofBlood from bloodquantity where bloodGrp='"+bg+"'");
            }
            if (bg.equals("AB-")) {
                stat = conn.prepareStatement("select packetsofBlood from bloodquantity where bloodGrp='"+bg+"'");
            }

            ResultSet rs = stat.executeQuery();
            rs.next();
            int pkno = rs.getInt(1);
            if (pkno == 0) {
                JOptionPane.showMessageDialog(this, "Not Available", "Empty", JOptionPane.PLAIN_MESSAGE);
            }
            
            else {
                pkno -= 1;
                stat = conn.prepareStatement("update bloodquantity set packetsofBlood=? where bloodGrp=?");
                stat.setInt(1, pkno);
                stat.setString(2, bg);
                this.dispose();
                stat.executeUpdate();
            
            
            JOptionPane.showMessageDialog(null, "Patient's Details Added Successfully, Blood Packet ready to dispatch");
            }
            setVisible(false);
            new SellBlood().setVisible(true);
        }
            
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_submitBtnActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SellBlood().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton closeBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextArea pAddress;
    private javax.swing.JComboBox<String> pBloodGrp;
    private javax.swing.JTextField pCity;
    private com.toedter.calendar.JDateChooser pDob;
    private javax.swing.JTextField pEmail;
    private javax.swing.JComboBox<String> pGender;
    private javax.swing.JTextField pMobile;
    private javax.swing.JTextField pName;
    private javax.swing.JButton resetBtn;
    private javax.swing.JButton submitBtn;
    // End of variables declaration//GEN-END:variables
}
