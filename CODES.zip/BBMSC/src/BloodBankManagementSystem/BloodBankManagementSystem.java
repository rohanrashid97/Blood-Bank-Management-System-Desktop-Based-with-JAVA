package BloodBankManagementSystem;

public class BloodBankManagementSystem {
    public static void main(String[] args) {
        System.out.println("App is running");
        new Login().setVisible(true);
               
    }
    
}
